<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="x-US-COMPATIBLE" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scaled=1.0">
        <title>personal portfolio</title>
        <link rel="stylesheet" href="style.css">
    </head>

    <body>
        <header class="header">
            <a href="#" class="logo">Madumetja.</a>

            <nav class="navbar">
                <a href="#">Home</a>
                <a href="#">About</a>
                <a href="#">Services</a>
                <a href="#">Poetfolio</a>
                <a href="#">Contact</a>
            
            </nav>
        </header>
    </body>
</html>